//
//  ThreeLevelView.swift
//  My App
//
//  Created by Bayu Alif Farisqi on 18/04/23.
//

import SwiftUI

struct ThreeLevelView: View {
    
    @Environment(\.presentationMode) var presentationMode
    @State var isFinishAllChallenge: Bool = false
    //TRASH VARIABLE
    @State var trash1Position = CGPoint.zero
    @State var trash2Position = CGPoint.zero
    @State var trash3Position = CGPoint.zero
    @State var trash4Position = CGPoint.zero
    @State var trash5Position = CGPoint.zero
    @State var trash1Scale: CGFloat = 1.0
    @State var trash2Scale: CGFloat = 1.0
    @State var trash3Scale: CGFloat = 1.0
    @State var trash4Scale: CGFloat = 1.0
    @State var trash5Scale: CGFloat = 1.0
    @State var trash1Opacity: Double = 1.0
    @State var trash2Opacity: Double = 1.0
    @State var trash3Opacity: Double = 1.0
    @State var trash4Opacity: Double = 1.0
    @State var trash5Opacity: Double = 1.0
    @State var scoreCollectTrash = 0
    
    //TREE VARIABLE
    @State var isTreeDropInArea: Bool = false
    @State var tree1Position = CGPoint.zero
    @State var tree2Position = CGPoint.zero
    @State var tree3Position = CGPoint.zero
    @State var tree4Position = CGPoint.zero
    @State var isTree1Dropped: Bool = false
    @State var isTree2Dropped: Bool = false
    @State var isTree3Dropped: Bool = false
    @State var isTree4Dropped: Bool = false
    @State var scorePlantsTree = 0
    @State var isInfoOpen: Bool = false
    
    var body: some View {
        GeometryReader{ geo in
            ZStack{
                Image("backgroundLevel3")
                    .resizable()
                    .edgesIgnoringSafeArea(.all)
                //TRASH VIEW
                trashView
                trash
                
                //TREE VIEW
                landArea
                treeGroup
                scoreArea
                //GENERAL INFO
                instruction
                buttonInfo
                if isInfoOpen{
                    endemicInfo
                }
                if isFinishAllChallenge{
                    finishAction
                }
            }
        }
    }
    var buttonInfo: some View{
        GeometryReader{geo in
            Button(action: {
                isInfoOpen = true
            },label: {
                Circle()
                    .fill(Color.white)
                    .frame(width: 75, height: 75)
                    .shadow(radius: 10)
                    .overlay(
                        Image(systemName: "info.circle.fill")
                            .font(.system(size: 50))
                            .foregroundColor(Color.blue)
                    )
            })
            .position(x: geo.size.width/1.1)
            .padding(.top,50)
        }
    }
    var instruction: some View{
        GeometryReader{geo in
            ZStack{
                HStack{
                    Image("boy2")
                        .resizable()
                        .scaledToFit()
                        .frame(width: geo.size.width/5)
                    Text("I think you know a way to rescue the Cendrawasih Birds")
                        .foregroundColor(.black)
                        .font(.title)
                        .frame(width: geo.size.width/2)
                        .padding(10)
                        .background(Color.white)
                        .cornerRadius(10)
                    Image("girl3")
                        .resizable()
                        .scaledToFit()
                        .frame(width: geo.size.width/5.5)
                        .offset(x:-30, y: 30)
                }.position(x: geo.size.width/2, y: geo.size.height/1.15)
                
            }
        }
    }
    var endemicInfo: some View{
        ZStack{
            Color.black.opacity(0.4)
                .edgesIgnoringSafeArea(.all)
            VStack{
                Image("cendrawasihBirds1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200)
                
                Text("ENDEMIC INFO")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .padding()
                    .padding(.horizontal)
                    .background(Color.orange.opacity(0.8))
                    .cornerRadius(20)
                VStack(alignment:.leading){
                    Text("Name")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.orange)
                        .multilineTextAlignment(.leading)
                    Text("Cendrawasih Birds (Paradisaeidae)")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .multilineTextAlignment(.leading)
                    Text("Type")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.orange)
                        .multilineTextAlignment(.leading)
                    Text("Aves")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .multilineTextAlignment(.leading)
                    Text("Habitats")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.orange)
                        .multilineTextAlignment(.leading)
                    Text("Tropical rains in Papua, especially in mountainous areas")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .multilineTextAlignment(.leading)
                    Text("Conservation Status")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.orange)
                        .multilineTextAlignment(.leading)
                    Text("Endangered ")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .multilineTextAlignment(.leading)
                        .background(.red)
                }
                Button(action: {
                    isInfoOpen = false
                },label: {
                    
                    Circle()
                        .fill(Color.white)
                        .frame(width: 75, height: 75)
                        .shadow(radius: 10)
                        .overlay(
                            Image(systemName: "x.circle.fill")
                                .font(.system(size: 50))
                                .foregroundColor(Color.red)
                        )
                })
                
                
            }
            .padding(50)
            .background(
                Color.brown
            )
            .cornerRadius(25)
            .padding(16)
            .transition(AnyTransition.scale.animation(.easeInOut))
        }
    }
    var scoreArea: some View{
        GeometryReader{ geo in
            HStack{
                HStack{
                    Image("tree1")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 70)
                        .padding(.horizontal)
                    Text("\(scorePlantsTree) / 4")
                        .font(.system(size: 40))
                        .fontWeight(.bold)
                        .foregroundColor(.green)
                }.padding()
                    .background(Color.white)
                    .cornerRadius(20)
                    .shadow(radius: 10)
                HStack{
                    Image("trashCan")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 70)
                        .padding(.horizontal)
                    Text("\(scoreCollectTrash) / 5")
                        .font(.system(size: 40))
                        .fontWeight(.bold)
                        .foregroundColor(.green)
                }.padding()
                    .background(Color.white)
                    .cornerRadius(20)
                    .shadow(radius: 10)
            }
            .padding(.horizontal, 20)
        }
    }
    var finishAction: some View{
        ZStack{
            Color.black.opacity(0.4)
                .edgesIgnoringSafeArea(.all)
            VStack{
                Text("CONGRATULATION🌟🌟🌟")
                    .font(.system(size: 40))
                    .fontWeight(.bold)
                    .foregroundColor(.orange)
                    .padding()
                    .padding(.horizontal)
                    .background(Color.black.opacity(0.8))
                    .cornerRadius(20)
                Image("boy3")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200)
                Text("You have COMPLETED all the challenges\nDon't forget to always take care and rescue of nature, see you👋")
                    .font(.system(size: 40))
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .multilineTextAlignment(.center)
                Button(action: {
                    self.presentationMode.wrappedValue.dismiss()
                },label: {
                    
                    Text("FINISH")
                        .font(.system(size: 40))
                        .fontWeight(.bold)
                        .foregroundColor(.brown)
                        .padding()
                        .background(.white)
                        .cornerRadius(20)
                        .shadow(radius: 10)
                })
            }
            .padding(50)
            .background(
                Color.brown
            )
            .cornerRadius(25)
            .padding(16)
            .shadow(radius: 50)
            .transition(AnyTransition.scale.animation(.easeInOut))
        }
        
    }
    //TREE VIEW
    var birdsArea: some View{
        GeometryReader{ geo in
            Image("cendrawasihBirds1")
                .resizable()
                .scaledToFit()
                .frame(width: 200)
                .position(x: geo.size.width / 1.4, y: geo.size.height / 7)
        }
    }
    var landArea: some View {
        
        GeometryReader{ geo in
            let landAreaRect = CGRect(x: geo.size.width / 6, y: geo.size.height / 5, width: geo.size.width / 1.52, height: geo.size.height / 8)
            ZStack{
                birdsArea
                Rectangle()
                    .stroke(Color.black.opacity(0.4), style: StrokeStyle(lineWidth: 10, lineCap: .round, dash: [25]))
                    .frame(width: landAreaRect.width, height: landAreaRect.height)
                    .overlay(
                        Text("Drop Tree Here")
                            .foregroundColor(Color.black.opacity(0.5))
                            .font(.largeTitle)
                            .bold()
                            .opacity(isTreeDropInArea ? 0 : 1)
                        
                    )
                    .position(x: landAreaRect.midX, y: landAreaRect.midY)
            }
            
        }
    }
    var treeGroup: some View{
        GeometryReader{ geo in
            let landAreaRect = CGRect(x: geo.size.width / 6, y: geo.size.height / 5, width: geo.size.width / 1.52, height: geo.size.height / 8)
          
            ZStack{
                Rectangle()
                    .fill(Color.green)
                    .frame(width:  geo.size.width / 2, height:  geo.size.width / 5)
                    .cornerRadius(20)
                    .overlay(
                        Rectangle()
                            .fill(Color.white)
                            .frame(width:  geo.size.width / 2.2, height:  geo.size.width / 5.7)
                            .cornerRadius(20)
                    )
                    .position(CGPoint(x: geo.size.width / 3, y: geo.size.height / 1.4))
                    .shadow(radius: 10)
                
                Image(isTree1Dropped ? "tree1" : "plants")
                    .resizable()
                    .scaledToFit()
                    .frame(width: geo.size.width / 12)
                    .position(tree1Position)
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                if !isTree1Dropped{
                                    tree1Position = value.location
                                }
                            }
                            .onEnded { value in
                                let treeRect = CGRect(x: tree1Position.x, y: tree1Position.y + 80, width: 10, height: 10)
                                if treeRect.intersects(landAreaRect) {
                                    withAnimation {
                                        tree1Position = CGPoint(x: geo.size.width / 2.2, y: geo.size.height / 5.5)
                                        isTreeDropInArea = true
                                        isTree1Dropped = true
                                        scorePlantsTree += 1
                                        if scorePlantsTree == 4 && scoreCollectTrash == 5{
                                            isFinishAllChallenge = true
                                        }
                                        
                                    }
                                }else{
                                    withAnimation{
                                        tree1Position = CGPoint(x: geo.size.width / 6, y: geo.size.height / 1.4)
                                    }
                                }
                            }
                    )
                Image(isTree2Dropped ? "tree1" : "plants")
                    .resizable()
                    .scaledToFit()
                    .frame(width: geo.size.width / 12)
                    .position(tree2Position)
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                if !isTree2Dropped{
                                    tree2Position = value.location
                                }
                            }
                            .onEnded { value in
                                let treeRect = CGRect(x: tree2Position.x, y: tree2Position.y + 80, width: 10, height: 10)
                                if treeRect.intersects(landAreaRect) {
                                    withAnimation {
                                        tree2Position = CGPoint(x: geo.size.width / 2.9, y: geo.size.height / 5.5)
                                        isTreeDropInArea = true
                                        isTree2Dropped = true
                                        scorePlantsTree += 1
                                        if scorePlantsTree == 4 && scoreCollectTrash == 5{
                                            isFinishAllChallenge = true
                                        }
                                    }
                                }else{
                                    withAnimation{
                                        tree2Position = CGPoint(x: geo.size.width / 3.5, y: geo.size.height / 1.4)
                                    }
                                }
                            }
                    )
                Image(isTree3Dropped ? "tree1" : "plants")
                    .resizable()
                    .scaledToFit()
                    .frame(width: geo.size.width / 12)
                    .position(tree3Position)
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                if !isTree3Dropped{
                                    tree3Position = value.location
                                }
                            }
                            .onEnded { value in
                                let treeRect = CGRect(x: tree3Position.x, y: tree3Position.y + 80, width: 10, height: 10)
                                if treeRect.intersects(landAreaRect) {
                                    withAnimation {
                                        tree3Position = CGPoint(x: geo.size.width / 1.8, y: geo.size.height / 5.5)
                                        isTreeDropInArea = true
                                        isTree3Dropped = true
                                        scorePlantsTree += 1
                                        if scorePlantsTree == 4 && scoreCollectTrash == 5{
                                            isFinishAllChallenge = true
                                        }
                                    }
                                }else{
                                    withAnimation{
                                        tree3Position = CGPoint(x: geo.size.width / 2.5, y: geo.size.height / 1.4)
                                    }
                                }
                            }
                    )
                Image(isTree4Dropped ? "tree1" : "plants")
                    .resizable()
                    .scaledToFit()
                    .frame(width: geo.size.width / 12)
                    .position(tree4Position)
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                if !isTree4Dropped{
                                    tree4Position = value.location
                                }
                            }
                            .onEnded { value in
                                let treeRect = CGRect(x: tree4Position.x, y: tree4Position.y + 80, width: 10, height: 10)
                                if treeRect.intersects(landAreaRect) {
                                    withAnimation {
                                        tree4Position = CGPoint(x: geo.size.width / 1.5, y: geo.size.height / 5.5)
                                        isTreeDropInArea = true
                                        isTree4Dropped = true
                                        scorePlantsTree += 1
                                        if scorePlantsTree == 4 && scoreCollectTrash == 5{
                                            isFinishAllChallenge = true
                                        }
                                    }
                                }else{
                                    withAnimation{
                                        tree4Position = CGPoint(x: geo.size.width / 2, y: geo.size.height / 1.4)
                                    }
                                }
                            }
                    )
            }
            .onAppear {
                tree1Position = CGPoint(x: geo.size.width / 6, y: geo.size.height / 1.4)
                tree2Position = CGPoint(x: geo.size.width / 3.5, y: geo.size.height / 1.4)
                tree3Position = CGPoint(x: geo.size.width / 2.5, y: geo.size.height / 1.4)
                tree4Position = CGPoint(x: geo.size.width / 2, y: geo.size.height / 1.4)
            }
            .onChange(of: geo.size) { _ in
                if !isTree1Dropped{
                    tree1Position = CGPoint(x: geo.size.width / 6, y: geo.size.height / 1.4)
                }else{
                    tree1Position = CGPoint(x: geo.size.width / 2.2, y: geo.size.height / 5.5)
                }
                if !isTree2Dropped{
                    tree2Position = CGPoint(x: geo.size.width / 3.5, y: geo.size.height / 1.4)
                }else{
                    tree2Position = CGPoint(x: geo.size.width / 2.9, y: geo.size.height / 5.5)
                }
                if !isTree3Dropped{
                    tree3Position = CGPoint(x: geo.size.width / 2.5, y: geo.size.height / 1.4)
                } else{
                    tree3Position = CGPoint(x: geo.size.width / 1.8, y: geo.size.height / 5.5)
                }
                if !isTree4Dropped{
                    tree4Position = CGPoint(x: geo.size.width / 2, y: geo.size.height / 1.4)
                }else{
                    tree4Position = CGPoint(x: geo.size.width / 1.5, y: geo.size.height / 5.5)
                }
            }
        }
    }
    //TRASH VIEW
    var trashView: some View{
        GeometryReader{ geo in
            let trashCanPosition = CGRect(x: geo.size.width / 1.6, y: geo.size.height / 1.55, width: geo.size.width / 5, height: geo.size.height / 8)
                ZStack{
                    Image("trashCan")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250)
                        .position(x: trashCanPosition.midX + 40, y: trashCanPosition.midY - 50)
                        
                }
        }
    }
    
    var trash: some View{
        GeometryReader{ geo in
            let trashCanRect =  CGRect(x: geo.size.width / 1.55, y: geo.size.height / 1.5, width: geo.size.width / 5, height: geo.size.height / 8)
            ZStack{
                Image("trash1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100)
                    .scaleEffect(trash1Scale)
                    .opacity(trash1Opacity)
                    .position(trash1Position)
                
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                trash1Position = value.location                          }
                            .onEnded { value in
                                let trashRect = CGRect(x: trash1Position.x, y: trash1Position.y, width: 50, height: 100)
                                if trashRect.intersects(trashCanRect) {
                                    withAnimation {
                                        trash1Scale = 0.0
                                        trash1Opacity = 0.1
                                        scoreCollectTrash += 1
                                        if scorePlantsTree == 4 && scoreCollectTrash == 5{
                                            isFinishAllChallenge = true
                                        }
                                    }
                                }else{
                                    withAnimation{
                                        trash1Position = CGPoint(x: geo.size.width / 8, y: geo.size.height / 2)
                                    }
                                }
                            }
                    )
                Image("trash2")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100)
                    .scaleEffect(trash2Scale)
                    .opacity(trash2Opacity)
                    .position(trash2Position)
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                trash2Position = value.location                          }
                            .onEnded { value in
                                let trashRect = CGRect(x: trash2Position.x, y: trash2Position.y, width: 100, height: 100)
                                if trashRect.intersects(trashCanRect) {
                                    withAnimation {
                                        trash2Scale = 0.0
                                        trash2Opacity = 0.1
                                        scoreCollectTrash += 1
                                            if scorePlantsTree == 4 && scoreCollectTrash == 5{
                                                isFinishAllChallenge = true
                                            }
                                    }
                                }else{
                                    withAnimation{
                                        trash2Position = CGPoint(x: geo.size.width / 1.4, y: geo.size.height / 2)
                                    }
                                }
                            }
                    )
                
                Image("trash3")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100)
                    .scaleEffect(trash3Scale)
                    .opacity(trash3Opacity)
                    .position(trash3Position)
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                trash3Position = value.location                          }
                            .onEnded { value in
                                let trashRect = CGRect(x: trash3Position.x, y: trash3Position.y, width: 100, height: 100)
                                if trashRect.intersects(trashCanRect) {
                                    withAnimation {
                                        trash3Scale = 0.0
                                        trash3Opacity = 0.1
                                        scoreCollectTrash += 1
                                            if scorePlantsTree == 4 && scoreCollectTrash == 5{
                                                isFinishAllChallenge = true
                                            }
                                        
                                    }
                                }else{
                                    withAnimation{
                                        trash3Position = CGPoint(x: geo.size.width / 1.2, y: geo.size.height / 2.4)
                                    }
                                }
                            }
                    )
                Image("trash4")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100)
                    .scaleEffect(trash4Scale)
                    .opacity(trash4Opacity)
                    .position(trash4Position)
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                trash4Position = value.location                          }
                            .onEnded { value in
                                let trashRect = CGRect(x: trash4Position.x, y: trash4Position.y, width: 100, height: 100)
                                if trashRect.intersects(trashCanRect) {
                                    withAnimation {
                                        trash4Scale = 0.0
                                        trash4Opacity = 0.1
                                        scoreCollectTrash += 1
                                            if scorePlantsTree == 4 && scoreCollectTrash == 5{
                                                isFinishAllChallenge = true
                                            }
                                        
                                    }
                                }else{
                                    withAnimation{
                                        trash4Position = CGPoint(x: geo.size.width / 2.8, y: geo.size.height / 2.4)
                                    }
                                }
                            }
                    )
                
                Image("trash5")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100)
                    .scaleEffect(trash5Scale)
                    .opacity(trash5Opacity)
                    .position(trash5Position)
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                trash5Position = value.location
                            }
                            .onEnded { value in
                                let trashRect = CGRect(x: trash5Position.x, y: trash5Position.y, width: 100, height: 100)
                                if trashRect.intersects(trashCanRect) {
                                    withAnimation {
                                        trash5Scale = 0.0
                                        trash5Opacity = 0.1
                                        scoreCollectTrash += 1
                                            if scorePlantsTree == 4 && scoreCollectTrash == 5{
                                                isFinishAllChallenge = true
                                            }
                                        
                                        
                                    }
                                }else{
                                    withAnimation{
                                        trash5Position = CGPoint(x: geo.size.width / 1.1, y: geo.size.height / 1.8)
                                    }
                                }
                            }
                    )
            }
            .onAppear {
                trash1Position = CGPoint(x: geo.size.width / 8, y: geo.size.height / 2)
                trash2Position = CGPoint(x: geo.size.width / 1.4, y: geo.size.height / 2)
                trash3Position = CGPoint(x: geo.size.width / 1.2, y: geo.size.height / 2.4)
                trash4Position = CGPoint(x: geo.size.width / 2.8, y: geo.size.height / 2.4)
                trash5Position = CGPoint(x: geo.size.width / 1.1, y: geo.size.height / 1.8)
            }
            .onChange(of: geo.size) { _ in
                trash1Position = CGPoint(x: geo.size.width / 8, y: geo.size.height / 2)
                trash2Position = CGPoint(x: geo.size.width / 1.4, y: geo.size.height / 2)
                trash3Position = CGPoint(x: geo.size.width / 1.2, y: geo.size.height / 2.4)
                trash4Position = CGPoint(x: geo.size.width / 2.8, y: geo.size.height / 2.4)
                trash5Position = CGPoint(x: geo.size.width / 1.1, y: geo.size.height / 1.8)

            }
        }
    }
}

struct ThreeLevelView_Previews: PreviewProvider {
    static var previews: some View {
        ThreeLevelView()
    }
}
