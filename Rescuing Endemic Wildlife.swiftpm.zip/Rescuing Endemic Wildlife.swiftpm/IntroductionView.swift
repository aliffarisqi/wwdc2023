//
//  IntroductionView.swift
//  My App
//
//  Created by Bayu Alif Farisqi on 17/04/23.
//

import SwiftUI

struct IntroductionView: View {
    @Environment(\.presentationMode) var presentationMode
    
    @State var isIntroductionOverlay: Bool = true
    @State var isBackgroundStory1: Bool = true
    @State var isBackgroundStory2: Bool = false
    @State var isBackgroundStory3: Bool = false
    @State var isLevel2Open: Bool = false
    
    var body: some View {
        ZStack{
            Rectangle()
                .fill(
                    LinearGradient(
                        gradient: Gradient(colors: [Color.blue.opacity(0.6), Color.white]),
                        startPoint: .top,
                        endPoint: .bottom
                    )
                )
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            indonesiaIsland
            animalCardLevel
            
            if isIntroductionOverlay{
                introductionOverlay
                if isBackgroundStory1{
                    backgroundStory1
                } else if isBackgroundStory2{
                    backgroundStory2
                } else if isBackgroundStory3{
                    backgroundStory3
                }
                
            }
            buttonAction
        }
        .edgesIgnoringSafeArea(.all)
        
    }
    
    var introductionOverlay: some View{
        // LAYER DEEP
        Rectangle()
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(.ultraThinMaterial)
            .foregroundColor(Color.black.opacity(0.2))
            .foregroundStyle(.ultraThinMaterial)
            .edgesIgnoringSafeArea(.all)
    }
    var indonesiaIsland: some View{
        GeometryReader{geo in
            ZStack{
                Image("indonesiaIslandGreen")
                    .resizable()
                    .scaledToFit()
                    .frame(width: geo.size.width/1.2)
                    .position(x: geo.size.width/2, y: geo.size.height/2)
            }
        }
    }
    var animalCardLevel:some View{
        GeometryReader{geo in
            ZStack{
                //LEVEL 1
                NavigationLink(destination: OneLevelView()) {
                    Image("pinMapsBlue")
                        .resizable()
                        .scaledToFit()
                        .frame(width: geo.size.height/6.5)
                        .overlay(
                            Image("pesutMahakamFish")
                                .resizable()
                                .scaledToFit()
                                .overlay(
                                    Text("RESCUE 1")
                                        .font(.system(size: 40))
                                        .fontWeight(.bold)
                                        .foregroundColor(.white)
                                        .frame(width: 200)
                                        .padding()
                                        .background(Color.brown)
                                        .cornerRadius(20)
                                        .offset(y:-200)
                                )
                        )
                }.position(x: geo.size.width/2.7, y: geo.size.height/2.5)
                
                //LEVEL 2
                NavigationLink(destination: TwoLevelView()) {
                    Image("pinMapsGreen")
                        .resizable()
                        .scaledToFit()
                        .frame(width: geo.size.height/6.5)
                        .overlay(
                            Image("komodo1")
                                .resizable()
                                .scaledToFit()
                                .overlay(
                                    Text("RESCUE 2")
                                        .font(.system(size: 35))
                                        .fontWeight(.bold)
                                        .foregroundColor(.white)
                                        .frame(width: 200)
                                        .padding()
                                        .background(Color.brown)
                                        .cornerRadius(20)
                                        .offset(y:-200)
                                )
                        )
                }.position(x: geo.size.width/1.75, y: geo.size.height/1.8)
                //LEVEL 3
                NavigationLink(destination: ThreeLevelView()) {
                    Image("pinMapsRed")
                        .resizable()
                        .scaledToFit()
                        .frame(width: geo.size.height/6.5)
                        .overlay(
                            Image("cendrawasihBirds1")
                                .resizable()
                                .scaledToFit()
                                .overlay(
                                    Text("RESCUE 3")
                                        .font(.system(size:40))
                                        .fontWeight(.bold)
                                        .foregroundColor(.white)
                                        .frame(width: 200)
                                        .padding()
                                        .background(Color.brown)
                                        .cornerRadius(20)
                                        .offset(y:-200)
                                )
                        )
                }.position(x: geo.size.width/1.3, y: geo.size.height/2.5)
            }
        }
    }
    var buttonAction: some View{
        GeometryReader{geo in
            HStack{
                if !isBackgroundStory1 && !isBackgroundStory2 && !isBackgroundStory3{
                    Button(action: {
                        isIntroductionOverlay.toggle()
                        isBackgroundStory1.toggle()
                    },label: {
                        Circle()
                            .fill(Color.white)
                            .frame(width: 75, height: 75)
                            .shadow(radius: 10)
                            .overlay(
                                Image(systemName: "info.circle.fill")
                                    .font(.system(size: 50))
                                    .foregroundColor(Color.blue)
                            )
                        
                    }).padding(.bottom, 50)
                        .padding(.horizontal)
                }
                Button(action: {
                    self.presentationMode.wrappedValue.dismiss()
                },label: {
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color.brown)
                        .frame(width: 75, height: 75)
                        .shadow(radius: 10)
                        .overlay(
                            Image(systemName: "house.fill")
                                .font(.system(size: 40))
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                        )
                }).padding(.bottom, 50)
            }.position(x: geo.size.width/2,y: geo.size.height/1.03)
        }
    }
    
    var backgroundStory1: some View{
        VStack{
            Image("indonesiaIslandBackgroundStory1")
                .resizable()
                .scaledToFit()
                .frame(maxWidth: 650)
            Text(information.infoIntroduction[0])
                .font(.title)
                .fontWeight(.semibold)
                .baselineOffset(4)
                .kerning(1.5)
                .multilineTextAlignment(.leading)
                .foregroundColor(.white)
                .padding()
                .padding(.bottom, 30)
            HStack{
                Spacer()
                HStack{
                    Button(action: {
                        isBackgroundStory1.toggle()
                        isBackgroundStory2.toggle()
                    }, label:{
                        Image(systemName: "arrow.right")
                            .font(.title)
                            .foregroundColor(Color.white)
                            .bold()
                            .padding(.horizontal)
                            .padding()
                            .padding(.vertical)
                    })
                    .background(
                        Color.black.opacity(0.5)
                    )
                }
                .cornerRadius(25)
            }
            .padding(.horizontal)
            .padding(.bottom)
            .overlay(
                HStack{
                    Image("boy8")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 150)
                    Image("girl1")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 120)
                        .offset(y: 20)
                }
                
                ,alignment: .bottomLeading
            )
        }
        .padding()
        .background(
            Color.brown
        )
        .cornerRadius(25)
        .padding(16)
        .padding(.horizontal, 60)
        .transition(AnyTransition.scale.animation(.easeInOut))
    }
    var backgroundStory2: some View{
        VStack{
            HStack{
                Image("komodo1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100)
                Image("pesutMahakamFish")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100)
                Image("cendrawasihBirds1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100)
            }
            
            Text(information.infoIntroduction[1])
                .font(.title)
                .fontWeight(.semibold)
                .baselineOffset(4)
                .kerning(1.5)
                .multilineTextAlignment(.leading)
                .foregroundColor(.white)
                .padding()
                .padding(.bottom, 30)
            HStack{
                Spacer()
                HStack{
                    Button(action: {
                        isBackgroundStory1.toggle()
                        isBackgroundStory2.toggle()
                    }, label:{
                        Image(systemName: "arrow.left")
                            .font(.title)
                            .foregroundColor(Color.white.opacity(0.4))
                            .padding(20)
                            .background(
                                Color.black.opacity(0.3)
                            )
                            .cornerRadius(25)
                    })
                    Button(action: {
                        isBackgroundStory2.toggle()
                        isBackgroundStory3.toggle()
                    }, label:{
                        Image(systemName: "arrow.right")
                            .font(.title)
                            .foregroundColor(Color.white)
                            .bold()
                            .padding(.horizontal)
                            .padding()
                            .padding(.vertical)
                            .background(
                                Color.black.opacity(0.5)
                            )
                            .cornerRadius(25)
                    })
                }
            }
            .padding(.horizontal)
            .padding(.bottom)
            .overlay(
                HStack{
                    Image("boy5")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 150)
                    Image("girl2")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 120)
                    
                }
                ,alignment: .bottomLeading
            )
        }
        .padding(.top, 50)
        .padding()
        .background(
            Color.brown
        )
        .cornerRadius(25)
        .padding(16)
        .padding(.horizontal, 60)
        .transition(AnyTransition.scale.animation(.easeInOut))
    }
    var backgroundStory3: some View{
        VStack{
            HStack{
                Image("trashGroup")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200)
                    .overlay(
                        Image(systemName: "x.circle.fill")
                            .font(.largeTitle)
                            .foregroundColor(.red)
                            .background(Color.white)
                            .cornerRadius(10)
                        ,alignment: .bottomLeading
                        
                    )
                Image("treeGroup")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200)
                    .overlay(
                        Image(systemName: "x.circle.fill")
                            .font(.largeTitle)
                            .foregroundColor(.red)
                            .background(Color.white)
                            .cornerRadius(10)
                        ,alignment: .bottomLeading
                        
                    )
            }
            Text(information.infoIntroduction[2])
                .font(.title)
                .fontWeight(.semibold)
                .baselineOffset(4)
                .kerning(1.5)
                .multilineTextAlignment(.leading)
                .foregroundColor(.white)
                .padding()
                .padding(.bottom, 30)
            HStack{
                Spacer()
                HStack{
                    Button(action: {
                        isBackgroundStory2.toggle()
                        isBackgroundStory3.toggle()
                    }, label:{
                        Image(systemName: "arrow.left")
                            .font(.title)
                            .foregroundColor(Color.white.opacity(0.4))
                            .padding(20)
                            .background(
                                Color.black.opacity(0.3)
                            )
                            .cornerRadius(25)
                    })
                    Button(action: {
                        isBackgroundStory3.toggle()
                        isIntroductionOverlay.toggle()
                    }, label:{
                        Image(systemName: "arrow.right")
                            .font(.title)
                            .foregroundColor(Color.white)
                            .bold()
                            .padding(.horizontal)
                            .padding()
                            .padding(.vertical)
                            .background(
                                Color.black.opacity(0.5)
                            )
                            .cornerRadius(25)
                    })
                }
            }
            .padding(.horizontal)
            .padding(.bottom)
            .overlay(
                HStack{
                    Image("boy1")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 150)
                    Image("girl6")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 120)
                    
                }
                ,alignment: .bottomLeading
            )
        }
        .padding(.top, 50)
        .padding()
        .background(
            Color.brown
        )
        .cornerRadius(25)
        .padding(16)
        .padding(.horizontal, 60)
        .transition(AnyTransition.scale.animation(.easeInOut))
    }
    
}

struct IntroductionView_Previews: PreviewProvider {
    static var previews: some View {
        IntroductionView()
    }
}
