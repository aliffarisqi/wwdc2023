import SwiftUI

struct ContentView: View {
    @State private var cloud1Offset: CGFloat = -200
    @State private var cloud3Offset: CGFloat = -200
    @State private var cloud2Offset: CGFloat = UIScreen.main.bounds.width + 150
    @State private var cloud4Offset: CGFloat = UIScreen.main.bounds.width + 150
    @State private var isAnimatingButtonPlay = false
    var body: some View {
        NavigationView{
            ScrollView{
                ZStack{
                    //CLOUD
                    cloudsView
                    //VIEW
                    titleView
                    //ANIMAL
                    animalView
                }
            }
            .background(
                Image("mainBackground1")
                    .resizable()
                    .scaledToFill()
            )
            .edgesIgnoringSafeArea(.all)
            
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
    
    var cloudsView: some View{
        ZStack{
            Image("cloud")
                .resizable()
                .scaledToFit()
                .frame(width: 250)
                .position(x: 0,y: 200)
                .offset(x: cloud1Offset)
                .onAppear {
                    withAnimation(Animation.linear(duration: 15).repeatForever(autoreverses: false)) {
                        self.cloud1Offset = UIScreen.main.bounds.width + 150
                    }
                }
            Image("cloud")
                .resizable()
                .scaledToFit()
                .frame(width: 150)
                .position(x: 0,y: 100)
                .offset(x: cloud2Offset)
                .onAppear {
                    withAnimation(Animation.linear(duration: 20).repeatForever(autoreverses: false)) {
                        self.cloud2Offset = -100
                    }
                }
            Image("cloud")
                .resizable()
                .scaledToFit()
                .frame(width: 200)
                .position(x: 0,y: 600)
                .offset(x: cloud4Offset)
                .onAppear {
                    withAnimation(Animation.linear(duration: 17).repeatForever(autoreverses: false)) {
                        self.cloud4Offset = -100
                    }
                }
            Image("cloud")
                .resizable()
                .scaledToFit()
                .frame(width: 150)
                .position(x: 0,y: 700)
                .offset(x: cloud3Offset)
                .onAppear {
                    withAnimation(Animation.linear(duration: 10).repeatForever(autoreverses: false)) {
                        self.cloud3Offset = UIScreen.main.bounds.width + 150
                    }
                }
        }
    }
    var animalView: some View{
        GeometryReader{ geo in
            ZStack{
                Image("cendrawasihBirds1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 250)
                    .position(x: geo.size.width / 1.3,y: geo.size.width / 5)
            }
        }    }
    var titleView: some View{
        VStack{
            Image("title")
                .resizable()
                .scaledToFit()
                .frame(width: 550)
                .padding(.bottom)
                .overlay(
                    HStack{
                        Image("boy1")
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: 200)
                        Spacer()
                        Image("girl6")
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: 200)
                            .offset(x:20)
                    }
                        .offset(y:150)
                )
            NavigationLink(destination: IntroductionView()) {
                Text("PLAY".uppercased())
                    .font(.system(size: 40))
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .padding()
                    .padding(.horizontal, 20)
                    .background(
                        Color.brown
                            .cornerRadius(10)
                            .shadow(
                                color: Color.black.opacity(0.2), radius: 10)
                    )
                    .scaleEffect(isAnimatingButtonPlay ? 1.2 : 1.0)
                    .onAppear {
                        withAnimation(Animation.easeInOut(duration: 1.5).repeatForever()) {
                            self.isAnimatingButtonPlay.toggle()
                        }
                    }
            }.padding(20)
                .padding(.bottom, 100)
        }.padding(.bottom)
            .padding(.top,150)
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().previewInterfaceOrientation(.landscapeLeft)
    }
}

