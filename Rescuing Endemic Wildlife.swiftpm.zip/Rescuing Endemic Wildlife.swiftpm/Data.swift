import SwiftUI

struct Info {
    let infoIntroduction: [String]
}
let information = Info(
    infoIntroduction: [
    "Indonesia is an archipelagic country consisting of more than 17,000 islands. \n\nIt is home to over 7,078 mammal species, 2,828 freshwater fish species, 6,336 marine fish species, 1,731 bird species, and 1,070 reptile species.",
    "Out of the thousands of species, there are 292 species of endemic mammals, 2,500 species of fish, 515 species of reptiles, and 430 species of birds in Indonesia. \n\nSome famous endemic species is the Komodo dragon, Pesut mahakam, and Cendrawasih Birds.",
    "But many of Indonesia's endemic animals are threatened with extinction due to the loss of habitat and environmental damage. \n\nThat's why we need to engage in conservation efforts, with properly clean of trash and Restoring the forests, to Rescue the animals."
    
    ]
)
